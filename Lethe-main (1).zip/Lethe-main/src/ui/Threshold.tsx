// The threshold (screen p7): a dark garden and one line, before anything else. Clicking anywhere begins your own
// garden with the first plantings, or returns to the one this browser keeps; "see a garden" opens the demo garden of
// ten memories (for anyone just looking).
// This first click also starts sound (src/sound), as browsers require a gesture before audio.

import { useEffect, useRef, useState } from 'react';
import { useGarden } from '../store/garden';
import { Button } from './ds';
import { useMuted } from './SoundToggle';
import { startStory } from './story';

/** The threshold fades away over this long once the person steps in. */
const LEAVE_MS = 1200;

export function Threshold() {
  const phase = useGarden((s) => s.phase);
  const muted = useMuted();
  const [leaving, setLeaving] = useState<null | 'own' | 'demo' | 'story'>(null);
  const enter = useRef<HTMLButtonElement>(null);
  // Back at the threshold after letting the garden go: step in afresh.
  useEffect(() => { if (phase === 'threshold') { setLeaving(null); enter.current?.focus(); } }, [phase]);

  useEffect(() => {
    if (!leaving) return;
    const t = setTimeout(() => {
      if (leaving === 'own') void useGarden.getState().enterOwn();
      else if (leaving === 'story') startStory();
      else useGarden.getState().seeDemo();
    }, LEAVE_MS);
    return () => clearTimeout(t);
  }, [leaving]);

  if (phase !== 'threshold') return null;
  return (
    <div className={`threshold${leaving ? ' is-leaving' : ''}`}>
      {/* The whole screen is the way in. */}
      <button ref={enter} type="button" className="threshold-enter" aria-label="enter: plant something you don't want to lose"
        onClick={() => setLeaving((l) => l ?? 'own')}>
        <span className="threshold-seed" aria-hidden />
        <span className="title-lg threshold-line">Plant something you don’t want to lose.</span>
        <span className="interface-sm threshold-hint">click anywhere to enter{muted ? '' : ' · sound on'}</span>
      </button>
      <div className="threshold-demo">
        <Button onClick={() => setLeaving((l) => l ?? 'demo')}>see a garden</Button>
        <Button onClick={() => setLeaving((l) => l ?? 'story')}>watch a season</Button>
      </div>
    </div>
  );
}
